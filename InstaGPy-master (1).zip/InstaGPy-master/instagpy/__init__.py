from .instagpy import InstaGPy
